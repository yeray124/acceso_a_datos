/**
 * 
 */
/**
 * 
 */
module Acceso_datos_yeray {
	requires java.xml;
}